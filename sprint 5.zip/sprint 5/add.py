# -*- coding: utf-8 -*-
"""
       (`-()_.-=-.
       /66  ,  ,  \
     =(o_/=//_(   /======`
         ~"` ~"~~`        C.E.
         
Created on Fri Jul 31 11:30:52 2020
@author: Chris
Contact :
    Christopher.eaby@gmail.com
"""
import pymongo #mongodb module
import tkinter as tk #gui
import ctypes

#creates mongodatabase and the collections
myclient = pymongo.MongoClient("mongodb+srv://chris_eaby:meateater@cluster0.4iwjw.mongodb.net/test")
mydb = myclient["LMS"]
act = mydb["Activities"]
spr = mydb["Sprints"]
ref = mydb["Reflections"]

def addactorref(type1, module, week, day, number, Complete):
    if " " in module:
        module.replace(" ", "")
    dict1 = {"Module":module, "Week":week, "Day":day, "Number":number, "Complete": Complete}
    if type1 == 1:
        act.insert_one(dict1)
        ctypes.windll.user32.MessageBoxW(0, "Added to the database", "Status", 1)
    if type1 == 2:
        ref.insert_one(dict1)
        ctypes.windll.user32.MessageBoxW(0, "Added to the database", "Status", 1)

def addspr(module, week, number, Complete):
    if " " in module:
        module.replace(" ", "")
    dict1 = {"Module":module, "Week":week, "Number":number, "Complete": Complete}
    spr.insert_one(dict1)
    ctypes.windll.user32.MessageBoxW(0, "Added to the database", "Status", 1)
            
gui = tk.Tk()
# sets the title 
gui.title("Database manager")
# sets the size
gui.geometry("390x240")

# creates text field for data input
txt = tk.Text(gui, fg = "white", bg = "purple", height = 1, width = 15)
# griding for the text field
txt.grid(row = 1, column = 1)
lbl2 = tk.Label(gui, text = "Module", justify = tk.CENTER, padx = 30, pady = 10)
# creates a label to show what the text field is for
lbl2.grid(row = 1, column = 0)
txt1 = tk.Text(gui, fg = "white", bg = "purple", height = 1, width = 15)
txt1.grid(row = 2, column = 1)
lbl3 = tk.Label(gui, text = "Week", justify = tk.CENTER, padx = 30, pady = 10)
lbl3.grid(row = 2, column = 0)
txt2 = tk.Text(gui, fg = "white", bg = "purple", height = 1, width = 15)
txt2.grid(row = 3, column = 1)
lbl4 = tk.Label(gui, text = "Day (not for sprint)", justify = tk.CENTER, padx = 30, pady = 10)
lbl4.grid(row = 3, column = 0)
txt3 = tk.Text(gui, fg = "white", bg = "purple", height = 1, width = 15)
txt3.grid(row = 4, column = 1)
lbl5 = tk.Label(gui, text = "Number", justify = tk.CENTER, padx = 30, pady = 10)
lbl5.grid(row = 4, column = 0)
txt4 = tk.Text(gui, fg = "white", bg = "purple", height = 1, width = 15)
txt4.grid(row = 5, column = 1)
lbl6 = tk.Label(gui, text = "Complete(True/False)", justify = tk.CENTER, padx = 30, pady = 10)
lbl6.grid(row = 5, column = 0)

# creates buttons for all the functions
b1 = tk.Button(gui, text = "Reflection", height = 2, width = 9, command = lambda: addactorref(2, str(txt.get("1.0","end")), int(txt1.get("1.0","end")), int(txt2.get("1.0","end")), int(txt3.get("1.0","end")), bool(txt4.get("1.0","end"))))
b1.grid(row = 6, column = 0) 
b1 = tk.Button(gui, text = "Sprint", height = 2, width = 9, command = lambda: addspr(str(txt.get("1.0","end")), int(txt1.get("1.0","end")),int(txt3.get("1.0","end")), bool(txt4.get("1.0","end"))))
b1.grid(row = 6, column = 1) 
b2 = tk.Button(gui, text = "Activity", height = 2, width = 9, command = lambda: addactorref(1, str(txt.get("1.0","end")), int(txt1.get("1.0","end")), int(txt2.get("1.0","end")), int(txt3.get("1.0","end")), bool(txt4.get("1.0","end"))))
b2.grid(row = 6, column = 2) 

gui.mainloop()

